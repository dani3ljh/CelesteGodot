using Godot;
using System;

public partial class Player : CharacterBody2D
{
	public const float Speed = 300.0f;
	public const float DashHorizVelocity = 1600.0f;
	public const float DashVertVelocity = 900.0f;
	public const float JumpVelocity = -500.0f;

	public override void _PhysicsProcess(double delta)
	{
		Vector2 velocity = Velocity;

		// Add the gravity.
		if (!IsOnFloor())
		{
			velocity += GetGravity() * (float)delta;
		}

		// Handle Jump.
		if (Input.IsActionJustPressed("Jump") && IsOnFloor())
		{
			velocity.Y = JumpVelocity;
		}

		// Get the input direction and handle the movement/deceleration.
		// As good practice, you should replace UI actions with custom gameplay actions.
		Vector2 direction = Input.GetVector("Left", "Right", "Up", "Down");
		if (direction != Vector2.Zero && !Input.IsActionPressed("Dash"))
		{
			velocity.X = direction.X * Speed;
		}
		else if (!Input.IsActionPressed("Dash"))
		{
			velocity.X = Mathf.MoveToward(Velocity.X, 0, Speed);
		}
		
		if (Input.IsActionJustPressed("Dash")) {
			if (direction.X != 0 && direction.Y == 0) {
				velocity.Y = 0;
				velocity.X += DashHorizVelocity * direction.X;
			} else if (direction.Y != 0 && direction.X == 0) {
				velocity.X = 0;
				velocity.Y += DashVertVelocity * direction.Y;
			} else if (direction.X != 0 && direction.Y != 0){
				velocity.X += DashHorizVelocity * direction.X;
				velocity.Y += DashVertVelocity * direction.Y;
			}
		}
		
		Velocity = velocity;
		MoveAndSlide();
	}
}
